var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Drc_Storepickup/js/model/shipping-save-processor/default',
            'Magento_Checkout/js/checkout-data': 'Drc_Storepickup/js/checkout-data'
        }
    }
};