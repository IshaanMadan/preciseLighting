<?php
/**
 * Copyright © 2017 x-mage2(Yosto). All rights reserved.
 * See README.md for details.
 */

namespace Yosto\OpcSuccess\Helper;


use Magento\Framework\App\Helper\AbstractHelper;

class ConfigData extends AbstractHelper
{

}