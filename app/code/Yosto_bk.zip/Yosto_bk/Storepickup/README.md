#ONE STEP CHECKOUT - STORE PICKUP
###Main features
- Manage store locations
- Show store locations on Google Map
- Select store location from checkout page
- Add Store Pickup shipping method.
###Installation
- Download zip file
- Unzip file and copy all file from folder 'One Step Checkout' to {Magento 2 root folder}
- Run command: 
    + bin/magento setup:upgrade
    + bin/magento setup:static-content:deploy
- Go to admin and refresh cache.
###Support
Feel free to get support via email: support@x-mage2.com  