<?php
/**
 * Copyright © 2017 x-mage2(Yosto). All rights reserved.
 * See README.md for details.
 */
namespace Yosto\Storepickup\Model\ResourceModel\Location\Grid;

/**
 * Class Collection
 * @package Yosto\Storepickup\Model\ResourceModel\Location\Grid
 */
class Collection extends \Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult
{

}
