#ORDER ATTACHMENT FOR MAGENTO 2
###Main features
- Allow customer to upload an attachment on checkout page
- Ajax upload
- Configure file types, limited size.
###Installation
- Download zip file
- Unzip file and copy all file to {Magento 2 root folder}
- Run command: 
    + bin/magento setup:upgrade
    + bin/magento setup:static-content:deploy
- Go to admin and refresh cache.
###Support
Feel free to get support via email: support@x-mage2.com  