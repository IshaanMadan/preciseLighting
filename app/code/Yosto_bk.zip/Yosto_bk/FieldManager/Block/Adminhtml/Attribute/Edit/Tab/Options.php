<?php
/**
 * Copyright © 2017 x-mage2(Yosto). All rights reserved.
 * See README.md for details.
 */
namespace Yosto\FieldManager\Block\Adminhtml\Attribute\Edit\Tab;

class Options extends \Magento\Eav\Block\Adminhtml\Attribute\Edit\Options\AbstractOptions
{

}
