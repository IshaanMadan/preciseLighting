<?php
/**
 * Copyright © 2017 x-mage2(Yosto). All rights reserved.
 * See README.md for details.
 */

namespace Yosto\FieldManager\Block\Adminhtml\Attribute\Helper\Form;

/**
 * Class Apply
 * @package Yosto\CustomerAttribute\Block\Adminhtml\Attribute\Helper\Form
 */
class Apply extends \Magento\Catalog\Block\Adminhtml\Product\Helper\Form\Apply
{

}