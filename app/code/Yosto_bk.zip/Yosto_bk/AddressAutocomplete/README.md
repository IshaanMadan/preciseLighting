#ONE STEP CHECKOUT - ADDRESS AUTO COMPLETE
###Main features
- Integrate with Google Place API (as known as Google Map API)
- Auto complete address form fields when customer input street address information.
###Installation
- Download zip file
- Unzip file and copy all file from folder 'One Step Checkout' to {Magento 2 root folder}
- Run command: 
    + bin/magento setup:upgrade
    + bin/magento setup:static-content:deploy
- Go to admin and refresh cache.
###Support
Feel free to get support via email: support@x-mage2.com  