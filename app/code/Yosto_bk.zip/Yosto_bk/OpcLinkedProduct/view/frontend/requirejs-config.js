/**
 * Copyright © 2017 x-mage2(Yosto). All rights reserved.
 * See README.md for details.
 */
var config={
    "map":{
        "*":{
            "yosto.opc.product.slider":"Yosto_OpcLinkedProduct/js/slick.min"
        }
    },
    "shim": {
        "Yosto_OpcLinkedProduct/js/slick.min":["jquery"]
    }

};