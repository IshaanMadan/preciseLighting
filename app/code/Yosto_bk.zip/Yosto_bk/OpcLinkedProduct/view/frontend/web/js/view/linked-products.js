define([
    'ko',
    'jquery',
    'uiComponent'
], function (ko, $, Component) {
    'use strict';
    return Component.extend({
        defaults: {
            template: 'Yosto_OpcLinkedProduct/linked-products'
        }
    })
});