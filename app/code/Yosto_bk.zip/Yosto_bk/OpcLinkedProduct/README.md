#Display Linked Products on Checkout Page
###Main features
- Insert linked products to checkout page
- Support relate, up-sell,cross-sell products
- Display as a slider
- Limited number of displayed products
###Installation
- Download zip file
- Unzip file and copy all files to {Magento 2 root folder}
- Run command: 
    + bin/magento setup:upgrade
    + bin/magento setup:static-content:deploy
- Go to admin and refresh cache.
###Support
Feel free to get support via email: support@x-mage2.com    
    
    
    
