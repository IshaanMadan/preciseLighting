var config = {
    "map": {
        "*": {
           // 'Magento_Checkout/js/model/shipping-save-processor/default': 'Yosto_DeliveryDate/js/model/shipping-save-processor/custom-default'
        }
    }
};