#ONE STEP CHECKOUT - DELIVERY DATE
###Main features
- Allow customers adding delivery information on checkout page.
- Support detailed configuration.
###Installation
- Download zip file
- Unzip file and copy all file from folder 'One Step Checkout' to {Magento 2 root folder}
- Run command: 
    + bin/magento setup:upgrade
    + bin/magento setup:static-content:deploy
- Go to admin and refresh cache.
###Support
Feel free to get support via email: support@x-mage2.com  